#include <avr/io.h>
enum States{Init, Wait, c, d, e}state;
unsigned char pina = 0x00;

void set_PWM(double frequency) {

	static double current_frequency;

	if (frequency != current_frequency) {
		if (!frequency) { TCCR3B &= 0x08; }
		else { TCCR3B |= 0x03; }
		if (frequency < 0.954)
      {
         OCR3A = 0xFFFF;
      }
		else if (frequency > 31250) {
          OCR3A = 0x0000;
       }
		else {
         OCR3A = (short)(8000000 / (128 * frequency)) - 1;
       }
		TCNT3 = 0;
		current_frequency = frequency;
	}
}
void PWM_on() {
	TCCR0A = (1 << COM3A0);
	TCCR0B = (1 << WGM32) | (1 << CS31) | (1 << CS30);
	set_PWM(0);
}
void PWM_off() {
	TCCR3A = 0x00;
	TCCR3B = 0x00;
}

void Tick() {
	switch (state) {
		case Init: state = Wait; break;
		case Wait:
			if (pina == 0x04) {
				state = c;
			}
			else if (pina == 0x02) {
				state = d;
			}
			else if (pina == 0x01) {
				state = e;
			}
			else {
				state = Wait;
			}
			break;
		case C:
			state = (pina == 0x04) ? c : Wait;
			break;
		case D:
			state = (pina == 0x02) ? d : Wait;
			break;
		case E:
			state = (pina == 0x01) ? e : Wait;
			break;
		default: break;
	}
	switch (state) {
		case Init: break;
		case Wait:
			set_PWM(0);
			break;
		case C:
			set_PWM(261.63);
			break;
		case D:
			set_PWM(293.66);
			break;
		case E:
			set_PWM(329.63);
			break;
		default: break;
	}
}

int main(void) {
	DDRA = 0x00; PORTA = 0xFF;
    DDRB = 0x08; PORTB = 0x00;
	PWM_on();

    while (1) {
		pina = ~PINA & 0x07;
		Tick();


    }
}
