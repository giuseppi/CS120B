#include <avr/io.h>
enum States{Init, Wait, Begin, Wait2}state;
unsigned char pina = 0x00;
unsigned char toggle = 0x00;
double frequencies[] = {261.63, 293.66, 329.63, 349.23, 392, 440, 493.88, 523.25};
unsigned char freq_at = 0;

void set_PWM(double frequency) {

	static double current_frequency;

	if (frequency != current_frequency) {
		if (!frequency) { TCCR3B &= 0x08; }
		else { TCCR3B |= 0x03; }
		if (frequency < 0.954)
      {
         OCR3A = 0xFFFF;
      }
		else if (frequency > 31250) {
          OCR3A = 0x0000;
       }
		else {
         OCR3A = (short)(8000000 / (128 * frequency)) - 1;
       }
		TCNT3 = 0;
		current_frequency = frequency;
	}
}
void PWM_on() {
	TCCR0A = (1 << COM3A0);
	TCCR0B = (1 << WGM32) | (1 << CS31) | (1 << CS30);
	set_PWM(0);
}
void PWM_off() {
	TCCR3A = 0x00;
	TCCR3B = 0x00;
}

void Tick() {
	switch (state) {
		case Init: state = Wait; break;
		case Wait: state = (toggle) ? Begin : Wait; break;
		case Begin:
			if (pina == 0x04) {
				toggle = 0;
				state = Wait2;
			}
		default: break;
	}
	switch (state) {
		case Init: break;
		case Wait:
			if (pina == 0x04) {
				toggle = 1;
				state = Wait2;
			}
			set_PWM(0);
			break;
		case Begin:
			if (pina == 0x04) {
				toggle = 0;
				state = Wait2;
			}
			else if (pina == 0x02 && freq_at < 7) { // going up
				freq_at++;
				state = Wait2;
			}
			else if (pina == 0x01 && freq_at > 0) { // going down
				freq_at--;
				state = Wait2;
			}
			set_PWM(frequencies[freq_at]);
			break;
		case Wait2:
			if (pina == 0x00) {
				if (toggle) {
					state = Begin;
				}
				else {
					state = Wait;
				}
			}
			break;
		default: break;
	}
}

int main(void) {
	DDRA = 0x00; PORTA = 0xFF;
    DDRB = 0x08; PORTB = 0x00;
	PWM_on();

    while (1) {
		pina = ~PINA & 0x07;
		Tick();


    }
}
